import { useEffect, useRef, useState } from "react";

type IconName =
  | "home"
  | "compass"
  | "library"
  | "plus"
  | "search"
  | "bell"
  | "download"
  | "sparkles"
  | "play"
  | "pause"
  | "skipBack"
  | "skipForward"
  | "shuffle"
  | "repeat"
  | "heart"
  | "volume"
  | "more"
  | "chevronRight"
  | "wave";

function Icon({ name, size = 20, filled = false }: { name: IconName; size?: number; filled?: boolean }) {
  const paths: Record<IconName, React.ReactNode> = {
    home: <><path d="m3 10 9-7 9 7"/><path d="M5 9v11h14V9"/><path d="M9 20v-7h6v7"/></>,
    compass: <><circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2.2 4.8-4.8 2.2 2.2-4.8 4.8-2.2Z"/></>,
    library: <><path d="M4 4v16M9 4v16"/><path d="m14 5 4-1 3 14-4 1-3-14Z"/></>,
    plus: <path d="M12 5v14M5 12h14"/>,
    search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 7h18s-3 0-3-7"/><path d="M10 19h4"/></>,
    download: <><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/></>,
    sparkles: <><path d="m12 3 1.2 3.8L17 8l-3.8 1.2L12 13l-1.2-3.8L7 8l3.8-1.2L12 3Z"/><path d="m18.5 14 .7 2.3 2.3.7-2.3.7-.7 2.3-.7-2.3-2.3-.7 2.3-.7.7-2.3Z"/><path d="m5 13 .8 2.2L8 16l-2.2.8L5 19l-.8-2.2L2 16l2.2-.8L5 13Z"/></>,
    play: <path d="m8 5 11 7-11 7V5Z"/>,
    pause: <><path d="M9 5v14"/><path d="M15 5v14"/></>,
    skipBack: <><path d="M5 5v14"/><path d="m19 6-9 6 9 6V6Z"/></>,
    skipForward: <><path d="M19 5v14"/><path d="m5 6 9 6-9 6V6Z"/></>,
    shuffle: <><path d="M16 3h5v5"/><path d="m4 20 5.5-5.5M21 3l-8.5 8.5"/><path d="M16 16h5v5"/><path d="m15 15 6 6M4 4l5.5 5.5"/></>,
    repeat: <><path d="m17 2 4 4-4 4"/><path d="M3 11V9a3 3 0 0 1 3-3h15"/><path d="m7 22-4-4 4-4"/><path d="M21 13v2a3 3 0 0 1-3 3H3"/></>,
    heart: <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z"/>,
    volume: <><path d="M11 5 6 9H2v6h4l5 4V5Z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/></>,
    more: <><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></>,
    chevronRight: <path d="m9 18 6-6-6-6"/>,
    wave: <><path d="M3 12v2M7 8v8M11 5v14M15 8v8M19 10v4"/></>,
  };
  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  );
}

const tracks = [
  {
    title: "Neon Afterglow",
    artist: "Luna Park",
    meta: "Dream Pop · 3:24",
    art: "art-neon",
    prompt: "Dreamy synths, midnight drive, soft female vocals",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
  },
  {
    title: "Slow Sunday",
    artist: "The Mellow Club",
    meta: "Lo-fi Soul · 2:48",
    art: "art-sunday",
    prompt: "Warm vinyl, lazy Sunday morning, soulful keys",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
  },
  {
    title: "Parallel Lines",
    artist: "Static Bloom",
    meta: "Indie Rock · 3:12",
    art: "art-lines",
    prompt: "Energetic indie guitars, youthful, uplifting chorus",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
  },
  {
    title: "Forest Letters",
    artist: "Mori",
    meta: "Acoustic · 2:56",
    art: "art-forest",
    prompt: "Intimate acoustic guitar, forest ambience, nostalgic",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",
  },
];

const mixes = [
  { title: "Late Night Coding", subtitle: "Focus without the noise", art: "mix-coding" },
  { title: "Golden Hour", subtitle: "Soft sounds for sunset", art: "mix-golden" },
  { title: "City Pop Drive", subtitle: "Retro rhythm, modern night", art: "mix-city" },
];

interface InstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

function formatTime(value: number) {
  if (!Number.isFinite(value)) return "0:00";
  const minutes = Math.floor(value / 60);
  const seconds = Math.floor(value % 60).toString().padStart(2, "0");
  return `${minutes}:${seconds}`;
}

export default function App() {
  const [activeNav, setActiveNav] = useState("Home");
  const [currentTrack, setCurrentTrack] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [liked, setLiked] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(65);
  const [prompt, setPrompt] = useState("");
  const [generating, setGenerating] = useState(false);
  const [generated, setGenerated] = useState(false);
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const track = tracks[currentTrack];

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.volume = volume / 100;
    if (playing) audio.play().catch(() => setPlaying(false));
    else audio.pause();
  }, [playing, currentTrack, volume]);

  useEffect(() => {
    const captureInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
    };
    const markInstalled = () => {
      setInstalled(true);
      setInstallPrompt(null);
    };
    window.addEventListener("beforeinstallprompt", captureInstallPrompt);
    window.addEventListener("appinstalled", markInstalled);
    setInstalled(window.matchMedia("(display-mode: standalone)").matches);
    return () => {
      window.removeEventListener("beforeinstallprompt", captureInstallPrompt);
      window.removeEventListener("appinstalled", markInstalled);
    };
  }, []);

  const selectTrack = (index: number) => {
    setCurrentTrack(index);
    setProgress(0);
    setPlaying(true);
    setLiked(false);
  };

  const changeTrack = (direction: number) => {
    setCurrentTrack((currentTrack + direction + tracks.length) % tracks.length);
    setProgress(0);
    setPlaying(true);
    setLiked(false);
  };

  const handleGenerate = () => {
    if (!prompt.trim() || generating) return;
    setGenerating(true);
    setGenerated(false);
    window.setTimeout(() => {
      setGenerating(false);
      setGenerated(true);
    }, 1600);
  };

  const installApp = async () => {
    if (!installPrompt) return;
    await installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    if (choice.outcome === "accepted") setInstallPrompt(null);
  };

  return (
    <div className="app-shell">
      <audio
        ref={audioRef}
        src={track.audio}
        onTimeUpdate={(event) => setProgress(event.currentTarget.currentTime)}
        onLoadedMetadata={(event) => setDuration(event.currentTarget.duration)}
        onEnded={() => changeTrack(1)}
      />

      <aside className="sidebar">
        <div className="brand">
          <span className="brand-mark"><Icon name="wave" size={22} /></span>
          <span>Sona</span>
        </div>

        <nav className="main-nav" aria-label="Main navigation">
          {[
            { label: "Home", icon: "home" as IconName },
            { label: "Discover", icon: "compass" as IconName },
            { label: "Your Library", icon: "library" as IconName },
          ].map((item) => (
            <button
              key={item.label}
              className={`nav-item ${activeNav === item.label ? "active" : ""}`}
              onClick={() => setActiveNav(item.label)}
            >
              <Icon name={item.icon} size={19} />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="nav-section">
          <p className="eyebrow">YOUR MUSIC</p>
          <button className="nav-item" onClick={() => document.getElementById("create")?.scrollIntoView({ behavior: "smooth" })}>
            <Icon name="plus" size={19} />
            Create with AI
          </button>
          <button className="nav-item" onClick={() => setActiveNav("Liked Songs")}>
            <Icon name="heart" size={19} />
            Liked Songs
          </button>
        </div>

        <div className="sidebar-footer">
          <div className="powered-dot"><Icon name="sparkles" size={14} /></div>
          <div>
            <span>Powered by</span>
            <strong>Suno AI</strong>
          </div>
        </div>
      </aside>

      <main>
        <header className="topbar">
          <div className="search">
            <Icon name="search" size={18} />
            <input aria-label="Search" placeholder="Search songs, artists, moods..." />
            <span className="shortcut">⌘ K</span>
          </div>
          <div className="header-actions">
            {installPrompt && !installed && (
              <button className="install-button" onClick={installApp}>
                <Icon name="download" size={16} />
                Install app
              </button>
            )}
            <button className="icon-button" aria-label="Notifications"><Icon name="bell" size={19} /></button>
            <button className="avatar" aria-label="Open profile">JP</button>
          </div>
        </header>

        <div className="content">
          <section className="hero">
            <div className="hero-copy">
              <span className="hero-kicker"><Icon name="sparkles" size={15} /> AI MUSIC, MADE FOR YOU</span>
              <h1>What will you<br />listen to today?</h1>
              <p>Describe a feeling, a moment, or a sound.<br />We'll turn it into music that's uniquely yours.</p>
              <button className="primary-button" onClick={() => document.getElementById("create")?.scrollIntoView({ behavior: "smooth" })}>
                <Icon name="sparkles" size={18} />
                Create a song
              </button>
            </div>
            <div className="hero-art" aria-hidden="true">
              <div className="orb orb-one" />
              <div className="orb orb-two" />
              <div className="orb orb-three" />
              <div className="vinyl">
                <div className="vinyl-ring ring-one" />
                <div className="vinyl-ring ring-two" />
                <div className="vinyl-label">
                  <Icon name="wave" size={28} />
                  <span>SONA</span>
                </div>
              </div>
              <div className="floating-note note-one">♪</div>
              <div className="floating-note note-two">♫</div>
            </div>
          </section>

          <section className="section">
            <div className="section-heading">
              <div>
                <span className="eyebrow purple">MADE WITH SUNO AI</span>
                <h2>Freshly generated</h2>
              </div>
              <button className="text-button">See all <Icon name="chevronRight" size={16} /></button>
            </div>
            <div className="track-grid">
              {tracks.map((item, index) => (
                <article className={`track-card ${index === currentTrack ? "selected" : ""}`} key={item.title}>
                  <button className={`album-art ${item.art}`} onClick={() => selectTrack(index)} aria-label={`Play ${item.title}`}>
                    <span className="art-glow" />
                    <span className="card-play"><Icon name={playing && index === currentTrack ? "pause" : "play"} size={20} filled={index !== currentTrack || !playing} /></span>
                  </button>
                  <div className="track-info">
                    <div>
                      <h3>{item.title}</h3>
                      <p>{item.artist}</p>
                    </div>
                    <button className="more-button" aria-label={`More options for ${item.title}`}><Icon name="more" size={18} /></button>
                  </div>
                  <span className="track-meta">{item.meta}</span>
                </article>
              ))}
            </div>
          </section>

          <section className="create-section" id="create">
            <div className="create-copy">
              <span className="hero-kicker"><Icon name="sparkles" size={15} /> CREATE WITH AI</span>
              <h2>Turn your idea into a song</h2>
              <p>No instruments. No studio. Just describe the sound in your head.</p>
            </div>
            <div className="prompt-box">
              <div className="prompt-input">
                <Icon name="sparkles" size={19} />
                <input
                  value={prompt}
                  onChange={(event) => {
                    setPrompt(event.target.value);
                    setGenerated(false);
                  }}
                  onKeyDown={(event) => event.key === "Enter" && handleGenerate()}
                  placeholder="A dreamy indie pop song about driving home at night..."
                  aria-label="Describe the song you want to create"
                />
                <button className="generate-button" onClick={handleGenerate} disabled={!prompt.trim() || generating}>
                  {generating ? "Creating..." : "Generate"}
                </button>
              </div>
              <div className="prompt-footer">
                <span>{generated ? "Your idea is ready. Suno connection required to generate the full track." : "Try a mood, genre, story, or moment"}</span>
                <span>{prompt.length}/200</span>
              </div>
            </div>
          </section>

          <section className="section mixes-section">
            <div className="section-heading">
              <div>
                <span className="eyebrow purple">CURATED FOR YOU</span>
                <h2>Mixes for your moment</h2>
              </div>
            </div>
            <div className="mix-grid">
              {mixes.map((mix, index) => (
                <button className={`mix-card ${mix.art}`} key={mix.title} onClick={() => selectTrack(index)}>
                  <span className="mix-overlay" />
                  <span className="mix-copy"><strong>{mix.title}</strong><small>{mix.subtitle}</small></span>
                  <span className="mix-play"><Icon name="play" size={18} filled /></span>
                </button>
              ))}
            </div>
          </section>
        </div>
      </main>

      <footer className="player">
        <div className="now-playing">
          <div className={`player-art ${track.art}`}><span /></div>
          <div className="player-title">
            <strong>{track.title}</strong>
            <span>{track.artist}</span>
          </div>
          <button className={`plain-button ${liked ? "liked" : ""}`} onClick={() => setLiked(!liked)} aria-label="Like track">
            <Icon name="heart" size={19} filled={liked} />
          </button>
        </div>
        <div className="player-center">
          <div className="player-controls">
            <button className="plain-button muted" aria-label="Shuffle"><Icon name="shuffle" size={17} /></button>
            <button className="plain-button" onClick={() => changeTrack(-1)} aria-label="Previous track"><Icon name="skipBack" size={18} filled /></button>
            <button className="main-play" onClick={() => setPlaying(!playing)} aria-label={playing ? "Pause" : "Play"}>
              <Icon name={playing ? "pause" : "play"} size={18} filled={!playing} />
            </button>
            <button className="plain-button" onClick={() => changeTrack(1)} aria-label="Next track"><Icon name="skipForward" size={18} filled /></button>
            <button className="plain-button muted" aria-label="Repeat"><Icon name="repeat" size={17} /></button>
          </div>
          <div className="progress-row">
            <span>{formatTime(progress)}</span>
            <input
              type="range"
              min="0"
              max={duration || 100}
              value={progress}
              onChange={(event) => {
                const next = Number(event.target.value);
                if (audioRef.current) audioRef.current.currentTime = next;
                setProgress(next);
              }}
              aria-label="Track progress"
            />
            <span>{formatTime(duration)}</span>
          </div>
        </div>
        <div className="volume-control">
          <Icon name="volume" size={19} />
          <input type="range" min="0" max="100" value={volume} onChange={(event) => setVolume(Number(event.target.value))} aria-label="Volume" />
        </div>
      </footer>
    </div>
  );
}
